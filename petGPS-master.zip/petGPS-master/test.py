
print("importing stuff")

import dotenv
import dateutil

print("Hello. Imported")